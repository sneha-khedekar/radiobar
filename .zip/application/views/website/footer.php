<!-- Scripts/Plugins ======================-->

<script src="<?php echo base_url().'web-assets/js/jquery-3.7.0.min.js'?>"></script>	
			<script src="<?php echo base_url().'web-assets/js/bootstrap.bundle.min.js'?>"></script>	
			<script src="<?php echo base_url().'web-assets/js/jquery.magnific-popup.min.js'?>"></script>	
			<script src="<?php echo base_url().'web-assets/js/swiper-bundle.min.js'?>"></script>
			<!-- text-opacity -->
			<script src="<?php echo base_url().'web-assets/js/gsap.min.js'?>"></script>
			<script src="<?php echo base_url().'web-assets/js/scrollTrigger.min.js'?>"></script>
			<script src="<?php echo base_url().'web-assets/js/text-opacity.js'?>"></script>
			<!-- text-opacity -->

			<!-- counter-up -->
			<script src="<?php echo base_url().'web-assets/js/odometer.js'?>"></script>			
			<!-- counter-up -->				
			<script src="<?php echo base_url().'web-assets/js/countdown.js'?>"></script>
			<script src="<?php echo base_url().'web-assets/js/scroll.js'?>"></script>
			
			<!-- map -->			
			<script src="<?php echo base_url().'web-assets/js/leaflet.js'?>"></script>
			<script src="<?php echo base_url().'web-assets/js/leaflet-routing-machine.min.js'?>"></script>
			<script src="<?php echo base_url().'web-assets/js/leaflet-scripts.js'?>"></script>
			<!-- map -->
			
			<!-- animation -->
			<script src="<?php echo base_url().'web-assets/js/wow.min.js'?>"></script>
			<script src="<?php echo base_url().'web-assets/js/animate.js'?>"></script>				
			<!-- animation -->
		
			

			<script src="<?php echo base_url().'web-assets/js/scripts.js'?>"></script>
		<!-- Scripts/Plugins ======================-->
		
	</body>
</html>